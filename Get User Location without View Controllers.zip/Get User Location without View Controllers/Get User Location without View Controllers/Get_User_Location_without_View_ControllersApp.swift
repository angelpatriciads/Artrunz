//
//  Get_User_Location_without_View_ControllersApp.swift
//  Get User Location without View Controllers
//
//  Created by Angelica Patricia on 21/05/23.
//

import SwiftUI

@main
struct Get_User_Location_without_View_ControllersApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
